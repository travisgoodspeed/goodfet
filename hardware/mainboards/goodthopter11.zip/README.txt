GoodThopter11 CAN Adapter

The GoodThopter is the sexy GoodFET CAN Adapter, whose purpose is to
route CAN connection from an automobile or ECU into a laptop
leveraging the maturing GoodFET firmware and project.  Care has been
taken to keep the design easy to solder and the code easy to modify.



If you like this project, the following will humbly accept beer
donations:

Andrew Righter, GoodThopter Project Lead
Travis Goodspeed, Circuit Preacher

CAN Hacking Inspired By:
-Late night drinking in the Midwest with Atlas and Cutaway.

If you have any questions/comments:

Andrew Righter <andrew@215LAB.com>

bugs/development:
goodfet-devel@lists.sourceforge.net
