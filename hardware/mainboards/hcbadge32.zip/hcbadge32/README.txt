The following are Gerber files for manufacturing:

gerber top layer (copper layer): hcbadge32.GTL
gerber top overlay (silkscreen layer): hcbadge32.GTO
gerber top soldermask (soldermask layer): hcbadge32.GTS
gerber bottom layer (copper layer): hcbadge32.GBL
gerber bottom overlay (silkscreen layer): hcbadge32.GBO
gerber bottom soldermask (soldermask layer): hcbadge32.GBS
Excellon Drill File: hcbadge32.TXT

The following extra files might be of interest:

placet.ps     -- Top placement diagram, for documentation.
placeb.ps     -- Bottom placement diagram.
hcbadge32.cam -- Eagle CAM job for producing the Gerbers.
hcbadge32.brd -- Eagle CAD Board file, compatible with Freeware edition.
hcbadge32.sch -- Eagle CAD Schematic file, compat with Freeware edition.
hc_logo.*     -- Hushcon logo.
BOM.txt       -- Bill of Materials
