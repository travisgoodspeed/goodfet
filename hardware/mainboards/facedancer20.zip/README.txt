Facedancer11, a GoodFET for exploiting USB.
by Travis Goodspeed and Sergey Bratus
http://goodfet.sf.net/

The Facedancer20 board exposes a MAX3421 USB device controller to
Python, allowing a good neighbor to explore the vulnerabilities of
poorly written USB device drivers, prototype USB devices, or otherwise
play with USB as a network instead of as a magic school bus.

The MAX3421 is a bit harder to solder than the '3420 which was used in
earlier revisions of the Facedancer board, but it has the advantage of
offering USB host mode.



