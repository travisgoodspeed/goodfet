
DIRECTORY STRUCTURE:
/bom - Contains Bill of Materials, Including DigiKey Part numbers
/grb - Gerber Files, Zipped and Packaged Ready-to-be-Sent to PCB Manufacturer
/lbr - Library files created for this project

--

If you like this project, the following will humbly accept beer donations:

Project Lead:
 Andrew Righter

Design and Schematic:
 Andrew Righter
 Travis Goodspeed

Board and Routing:
 Ryan Barnes

CAN Hacking Inspired By:
-Late night drinking in the Midwest with atlas and cutaway

This is the sexy GoodFET CAN Adapter, its purpose is to build an adapter that can handle CAN 
connection from an automobile or ECU into a laptop leveraging the maturing GoodFET firmware and project. 

Future releases may include radio (RF) hardware appliable to vehicle applications and other fun things, 
if you have any questions/comments:

andrew@215LAB.com

bugs/development:
goodfet-devel@lists.sourceforge.net
